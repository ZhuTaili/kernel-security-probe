#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x248c59f, "netlink_broadcast" },
	{ 0xab8a633f, "kfree_skb_reason" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x9f984513, "strrchr" },
	{ 0x122c3a7e, "_printk" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x6a5cb5ee, "__get_free_pages" },
	{ 0x4fb3d3d, "d_path" },
	{ 0x5a921311, "strncmp" },
	{ 0x4302d0eb, "free_pages" },
	{ 0xab98e885, "netlink_kernel_release" },
	{ 0xa280f4a3, "init_net" },
	{ 0x6ea1e07e, "__netlink_kernel_create" },
	{ 0x3f66a26e, "register_kprobe" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x96848186, "scnprintf" },
	{ 0x817e8e14, "param_array_ops" },
	{ 0xf0090d06, "param_ops_ushort" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xbb10e61d, "unregister_kprobe" },
	{ 0x54b1fac6, "__ubsan_handle_load_invalid_value" },
	{ 0xc4f0da12, "ktime_get_with_offset" },
	{ 0x7ab1f0cb, "pcpu_hot" },
	{ 0xa916b694, "strnlen" },
	{ 0xdd64e639, "strscpy" },
	{ 0xa3a55323, "__alloc_skb" },
	{ 0x3619326, "__nlmsg_put" },
	{ 0x73776b79, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "FC81F0A423AB2A1D3945EAF");
