/*
 * secprobe_monitor.c
 *
 * secprobe 用户态实时展示程序
 *
 * 功能：
 *   1. 通过 Netlink 接收内核模块已经确认的安全告警
 *   2. 展示 EXEC / FILE / NET 三类告警
 *   3. 统计 MEDIUM / HIGH / CRITICAL 告警数量
 *   4. 对短时间内重复的相同告警进行显示合并
 *
 * 说明：
 *   安全判断逻辑不在本程序中实现；
 *   本程序只负责接收和展示 secprobe.ko 发送的结果。
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <sys/socket.h>
#include <linux/netlink.h>

#include "../common/secprobe_event.h"

#define MAX_RECENT_ALERTS 10
#define DISPLAY_TIME_LEN  32

static volatile sig_atomic_t running = 1;

/*
 * 展示层事件结构。
 * count 用于合并短时间内重复出现的相同告警。
 */
struct display_alert {
    struct secprobe_alert_event event;
    unsigned int count;
};

/* 最近告警列表 */
static struct display_alert recent_alerts[MAX_RECENT_ALERTS];
static unsigned int recent_count;

/* 统计数据 */
static unsigned int total_received;
static unsigned int medium_count;
static unsigned int high_count;
static unsigned int critical_count;

static unsigned int exec_count;
static unsigned int file_count;
static unsigned int net_count;

/*
 * Ctrl+C 退出程序。
 */
static void signal_handler(int sig)
{
    (void)sig;
    running = 0;
}

/*
 * 告警类型转字符串。
 */
static const char *type_name(__u32 type)
{
    switch (type) {
    case SECPROBE_ALERT_EXEC:
        return "EXEC";
    case SECPROBE_ALERT_FILE:
        return "FILE";
    case SECPROBE_ALERT_NET:
        return "NET";
    default:
        return "UNKNOWN";
    }
}

/*
 * 告警等级转字符串。
 */
static const char *severity_name(__u32 severity)
{
    switch (severity) {
    case SECPROBE_SEVERITY_MEDIUM:
        return "MEDIUM";
    case SECPROBE_SEVERITY_HIGH:
        return "HIGH";
    case SECPROBE_SEVERITY_CRITICAL:
        return "CRITICAL";
    default:
        return "UNKNOWN";
    }
}

/*
 * 将内核时间戳转换为本地显示时间。
 */
static void format_time(__u64 timestamp_ns, char *buffer, size_t size)
{
    time_t seconds;
    struct tm local_time;

    seconds = (time_t)(timestamp_ns / 1000000000ULL);

    if (localtime_r(&seconds, &local_time) == NULL) {
        snprintf(buffer, size, "--:--:--");
        return;
    }

    strftime(buffer, size, "%H:%M:%S", &local_time);
}

/*
 * 判断新事件是否与最新展示事件相同。
 *
 * 同一 PID、同一类别、同一等级、同一动作、同一目标，
 * 且在 1 秒内重复出现，则在展示界面中合并为 xN。
 *
 * 这只影响界面显示，不影响内核实际检测。
 */
static int is_short_duplicate(const struct secprobe_alert_event *event)
{
    const struct secprobe_alert_event *last;
    __u64 diff_ns;

    if (recent_count == 0)
        return 0;

    last = &recent_alerts[recent_count - 1].event;

    if (last->timestamp_ns > event->timestamp_ns)
        return 0;

    diff_ns = event->timestamp_ns - last->timestamp_ns;

    if (diff_ns > 1000000000ULL)
        return 0;

    if (last->type != event->type ||
        last->severity != event->severity ||
        last->pid != event->pid)
        return 0;

    if (strcmp(last->action, event->action) != 0)
        return 0;

    if (strcmp(last->target, event->target) != 0)
        return 0;

    return 1;
}

/*
 * 更新统计信息。
 *
 * 即使展示中发生重复合并，实际接收到的告警数仍然会累计。
 */
static void update_statistics(const struct secprobe_alert_event *event)
{
    total_received++;

    switch (event->severity) {
    case SECPROBE_SEVERITY_MEDIUM:
        medium_count++;
        break;
    case SECPROBE_SEVERITY_HIGH:
        high_count++;
        break;
    case SECPROBE_SEVERITY_CRITICAL:
        critical_count++;
        break;
    default:
        break;
    }

    switch (event->type) {
    case SECPROBE_ALERT_EXEC:
        exec_count++;
        break;
    case SECPROBE_ALERT_FILE:
        file_count++;
        break;
    case SECPROBE_ALERT_NET:
        net_count++;
        break;
    default:
        break;
    }
}

/*
 * 将事件保存到最近告警列表。
 */
static void add_recent_alert(const struct secprobe_alert_event *event)
{
    unsigned int i;

    if (is_short_duplicate(event)) {
        recent_alerts[recent_count - 1].count++;
        recent_alerts[recent_count - 1].event.timestamp_ns =
            event->timestamp_ns;
        return;
    }

    if (recent_count < MAX_RECENT_ALERTS) {
        recent_alerts[recent_count].event = *event;
        recent_alerts[recent_count].count = 1;
        recent_count++;
        return;
    }

    for (i = 1; i < MAX_RECENT_ALERTS; i++)
        recent_alerts[i - 1] = recent_alerts[i];

    recent_alerts[MAX_RECENT_ALERTS - 1].event = *event;
    recent_alerts[MAX_RECENT_ALERTS - 1].count = 1;
}

/*
 * 刷新终端显示界面。
 */
static void refresh_dashboard(void)
{
    unsigned int i;

    printf("\033[2J\033[H");

    printf("======================================================================\n");
    printf("                  Kernel Security Probe Monitor\n");
    printf("======================================================================\n");
    printf("Communication : Netlink realtime alert channel\n");
    printf("Detection     : Completed inside kernel module secprobe.ko\n");
    printf("Display note  : Short duplicate events are merged as xN\n");
    printf("----------------------------------------------------------------------\n");
    printf("Received alerts : %-6u   MEDIUM: %-6u HIGH: %-6u CRITICAL: %-6u\n",
           total_received, medium_count, high_count, critical_count);
    printf("Type summary    : EXEC: %-8u FILE: %-8u NET: %-8u\n",
           exec_count, file_count, net_count);
    printf("----------------------------------------------------------------------\n");
    printf("Recent kernel-confirmed alerts:\n\n");

    if (recent_count == 0) {
        printf("  Waiting for alerts from kernel module...\n");
    } else {
        for (i = 0; i < recent_count; i++) {
            char time_buffer[DISPLAY_TIME_LEN];
            struct secprobe_alert_event *event;
            struct display_alert *display;

            display = &recent_alerts[i];
            event = &display->event;

            format_time(event->timestamp_ns,
                        time_buffer,
                        sizeof(time_buffer));

            printf("  [%s] %-4s %-8s %-7s pid=%-6u comm=%-12s",
                   time_buffer,
                   type_name(event->type),
                   severity_name(event->severity),
                   event->action,
                   event->pid,
                   event->comm);

            if (display->count > 1)
                printf(" x%u", display->count);

            printf("\n");
            printf("             rule=%-24s target=%s\n",
                   event->rule,
                   event->target);
            printf("             uid=%u euid=%u\n\n",
                   event->uid,
                   event->euid);
        }
    }

    printf("----------------------------------------------------------------------\n");
    printf("Press Ctrl+C to exit.\n");
    printf("======================================================================\n");

    fflush(stdout);
}

/*
 * 处理一条从内核收到的告警。
 */
static void handle_event(const struct secprobe_alert_event *event)
{
    update_statistics(event);
    add_recent_alert(event);
    refresh_dashboard();
}

int main(void)
{
    int socket_fd;
    struct sockaddr_nl local_address;
    char buffer[NLMSG_SPACE(sizeof(struct secprobe_alert_event))];
    ssize_t received;

    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    /*
     * 创建 Netlink socket。
     * 当前内核模块下一步将使用同一个协议号发送告警。
     */
    socket_fd = socket(AF_NETLINK, SOCK_RAW, SECPROBE_NETLINK_PROTO);

    if (socket_fd < 0) {
        perror("socket");
        fprintf(stderr,
                "请确认支持 Netlink 的 secprobe V5 模块已加载。\n");
        return 1;
    }

    memset(&local_address, 0, sizeof(local_address));
    local_address.nl_family = AF_NETLINK;
    local_address.nl_pid = (unsigned int)getpid();
    local_address.nl_groups = SECPROBE_NETLINK_GROUP;

    if (bind(socket_fd,
             (struct sockaddr *)&local_address,
             sizeof(local_address)) < 0) {
        perror("bind");
        close(socket_fd);
        return 1;
    }

    refresh_dashboard();

    while (running) {
        struct nlmsghdr *header;
        int remaining;

        received = recv(socket_fd, buffer, sizeof(buffer), 0);

        if (received < 0) {
            if (errno == EINTR)
                continue;

            perror("recv");
            break;
        }

        if (received == 0)
            continue;

        remaining = (int)received;
        header = (struct nlmsghdr *)buffer;

        while (NLMSG_OK(header, remaining)) {
            if (header->nlmsg_type == NLMSG_DONE &&
                NLMSG_PAYLOAD(header, 0) >=
                    sizeof(struct secprobe_alert_event)) {
                const struct secprobe_alert_event *event;

                event = (const struct secprobe_alert_event *)
                        NLMSG_DATA(header);

                handle_event(event);
            }

            header = NLMSG_NEXT(header, remaining);
        }
    }

    close(socket_fd);

    printf("\nsecprobe_monitor exited.\n");

    return 0;
}
